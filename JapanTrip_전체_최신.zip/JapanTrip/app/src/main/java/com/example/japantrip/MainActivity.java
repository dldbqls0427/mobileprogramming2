package com.example.japantrip;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements TripStorage.ActivityListener {

    public static final String EXTRA_OPEN_PLAN = "open_plan";

    private BottomNavigationView bottomNav;
    private TripStorage storage;

    private final ActivityResultLauncher<String> notifPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    // 다른 탭으로 넘길 값
    private Place pendingPlace;
    private String pendingDestination;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 로그인하지 않았으면 로그인 화면으로
        if (!AuthStore.isLoggedIn(this)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);

        bottomNav = findViewById(R.id.bottom_nav);
        // 선택된 탭: 검은 동그라미 배경 대신 아이콘에 테두리만 (시안 모양)
        bottomNav.setItemActiveIndicatorEnabled(false);
        bottomNav.setItemIconTintList(null);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment f;
            if (id == R.id.nav_home) {
                f = new HomeFragment();
            } else if (id == R.id.nav_route) {
                f = RouteFragment.newInstance(pendingDestination);
                pendingDestination = null;
            } else if (id == R.id.nav_map) {
                f = MapViewFragment.newInstance(pendingPlace);
                pendingPlace = null;
            } else if (id == R.id.nav_plan) {
                f = new PlanFragment();
            } else {
                f = new MyPageFragment();
            }
            show(f);
            return true;
        });
        // 타임라인 같은 하위 화면에서 같은 탭을 다시 누르면 탭 첫 화면으로
        bottomNav.setOnItemReselectedListener(item ->
                getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE));

        if (savedInstanceState == null) {
            if (getIntent().getBooleanExtra(EXTRA_OPEN_PLAN, false)) {
                bottomNav.setSelectedItemId(R.id.nav_plan);
            } else {
                show(new HomeFragment());
            }
        }

        // 3단계: 친구가 일정을 바꾸면 알림
        Notifier.createChannel(this);
        askNotificationPermission();
        storage = TripStorage.get(this);
        storage.addActivityListener(this);
    }

    @Override
    protected void onDestroy() {
        if (storage != null) storage.removeActivityListener(this);
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getBooleanExtra(EXTRA_OPEN_PLAN, false)) bottomNav.setSelectedItemId(R.id.nav_plan);
    }

    /** 동행 친구의 활동 → 알림 */
    @Override
    public void onActivity(String who, String message) {
        Notifier.show(this, who + "님의 새 소식", message);
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS);
        }
    }

    private void show(Fragment f) {
        FragmentManager fm = getSupportFragmentManager();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        fm.beginTransaction().replace(R.id.fragment_container, f).commit();
    }

    /** 지도 탭(장소 상세)에서 장소 보여주기 */
    public void showPlaceOnMap(@Nullable Place place) {
        pendingPlace = place;
        if (bottomNav.getSelectedItemId() == R.id.nav_map) {
            show(MapViewFragment.newInstance(place));
            pendingPlace = null;
        } else {
            bottomNav.setSelectedItemId(R.id.nav_map);
        }
    }

    /** 여행교통 탭에서 길찾기 */
    public void openRoute(String destination) {
        pendingDestination = destination;
        bottomNav.setSelectedItemId(R.id.nav_route);
    }

    public void goToTab(int menuId) {
        bottomNav.setSelectedItemId(menuId);
    }

    /** 여행 정리 타임라인 (뒤로 가기로 돌아옴) */
    public void openTimeline() {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, new TimelineFragment())
                .addToBackStack("timeline")
                .commit();
    }
}
