package com.example.japantrip;

import java.io.Serializable;

/** 추천/지도용 장소 정보 */
public class Place implements Serializable {
    public final String name;
    public final float rating;   // 0이면 별점 없음
    public final String hours;
    public final String tag;     // "맛집" / "관광" / "역"
    public final Double lat;
    public final Double lng;

    public Place(String name, float rating, String hours, String tag, Double lat, Double lng) {
        this.name = name;
        this.rating = rating;
        this.hours = hours;
        this.tag = tag;
        this.lat = lat;
        this.lng = lng;
    }

    public boolean hasLocation() {
        return lat != null && lng != null;
    }

    public static Place from(PlanItem item) {
        Place known = TripRepository.find(item.name);
        if (known != null) return known;
        return new Place(item.name, (float) item.rating,
                item.hours != null ? item.hours : "영업시간 정보 없음", "", item.lat, item.lng);
    }
}
