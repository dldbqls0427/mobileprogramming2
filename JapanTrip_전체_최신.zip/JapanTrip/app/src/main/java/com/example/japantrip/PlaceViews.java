package com.example.japantrip;

import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/** 화면 공통 도우미 */
public final class PlaceViews {
    private PlaceViews() { }

    public static String rating(double r) {
        return r > 0 ? String.format(Locale.US, "%.1f / 5.0", r) : "별점 없음";
    }

    /** view_place_header 와 tv_hours 채우기 */
    public static void bind(View root, String name, double rating, String hours) {
        ((TextView) root.findViewById(R.id.tv_name)).setText(name);
        ((TextView) root.findViewById(R.id.tv_rating)).setText(rating(rating));
        TextView tv = root.findViewById(R.id.tv_hours);
        if (tv != null) tv.setText(hours != null ? hours : "영업시간 정보 없음");
    }

    public static void bind(View root, Place p) {
        bind(root, p.name, p.rating, p.hours);
    }

    public static int dp(Context c, int dp) {
        return (int) (dp * c.getResources().getDisplayMetrics().density);
    }

    /** 입력칸을 누르면 키보드가 한국어로 열리도록 요청 (Gboard에 한국어가 추가돼 있어야 함) */
    public static void korean(android.widget.EditText... fields) {
        if (android.os.Build.VERSION.SDK_INT < 24) return;
        for (android.widget.EditText et : fields) {
            et.setImeHintLocales(new android.os.LocaleList(Locale.KOREA));
        }
    }

    public static void toast(Context c, String s) {
        if (c != null) Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }
}
