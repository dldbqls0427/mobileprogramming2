package com.example.japantrip;

import android.app.TimePickerDialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.Locale;

/** 일정 항목(장소/메모) 추가·수정·삭제 창 */
public final class ItemEditDialog {

    private ItemEditDialog() { }

    /**
     * @param existing null 이면 새로 추가
     * @param type     새로 추가할 때 PlanItem.TYPE_PLACE 또는 TYPE_MEMO
     */
    public static void show(final Context ctx, final String dayKey, final PlanItem existing, String type) {
        final TripStorage storage = TripStorage.get(ctx);
        final boolean isNew = existing == null;
        final PlanItem item = isNew
                ? (PlanItem.TYPE_MEMO.equals(type) ? PlanItem.memo("") : PlanItem.place("", 0, null, null, null))
                : existing;
        final boolean memo = item.isMemo();

        View v = LayoutInflater.from(ctx).inflate(R.layout.dialog_item_edit, null);
        final EditText etName = v.findViewById(R.id.et_name);
        final EditText etNote = v.findViewById(R.id.et_note);
        final TextView tvTime = v.findViewById(R.id.tv_time_pick);
        PlaceViews.korean(etName, etNote);
        ((TextView) v.findViewById(R.id.label_name)).setText(memo ? "메모 내용" : "장소 이름");
        if (memo) {
            v.findViewById(R.id.label_note).setVisibility(View.GONE);
            etNote.setVisibility(View.GONE);
            etName.setMinLines(2);
        }

        etName.setText(item.name);
        etNote.setText(item.note);
        final String[] time = {item.time};
        tvTime.setText(time[0]);
        tvTime.setOnClickListener(x -> {
            int h = 12, m = 0;
            if (!TextUtils.isEmpty(time[0])) {
                h = Integer.parseInt(time[0].substring(0, 2));
                m = Integer.parseInt(time[0].substring(3, 5));
            }
            new TimePickerDialog(ctx, (picker, hh, mm) -> {
                time[0] = String.format(Locale.US, "%02d:%02d", hh, mm);
                tvTime.setText(time[0]);
            }, h, m, true).show();
        });
        tvTime.setOnLongClickListener(x -> {
            time[0] = null;
            tvTime.setText("");
            return true;
        });

        AlertDialog.Builder b = new AlertDialog.Builder(ctx)
                .setTitle(dayKey + (isNew ? (memo ? " 메모 추가" : " 장소 추가") : " 일정 수정"))
                .setView(v)
                .setNegativeButton("취소", null)
                .setPositiveButton(isNew ? "추가" : "저장", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    if (name.isEmpty()) {
                        PlaceViews.toast(ctx, memo ? "메모 내용을 입력하세요" : "장소 이름을 입력하세요");
                        return;
                    }
                    boolean renamed = !name.equals(item.name);
                    item.name = name;
                    item.time = time[0];
                    if (!memo) {
                        String note = etNote.getText().toString().trim();
                        item.note = note.isEmpty() ? null : note;
                        if (isNew || renamed) fillPlaceInfo(item);
                    }
                    storage.saveItem(dayKey, item);
                });
        if (!isNew) {
            b.setNeutralButton("삭제", (d, w) -> new AlertDialog.Builder(ctx)
                    .setMessage("'" + (memo ? "메모" : item.name) + "'를 삭제할까요?")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("삭제", (d2, w2) -> storage.deleteItem(dayKey, item))
                    .show());
        }
        b.show();
    }

    /** 앱에 들어 있는 장소면 별점/영업시간/좌표를 자동으로 채움 */
    private static void fillPlaceInfo(PlanItem item) {
        Place known = TripRepository.find(item.name);
        if (known != null) {
            item.rating = known.rating;
            item.hours = known.hours;
            item.lat = known.lat;
            item.lng = known.lng;
        } else {
            item.rating = 0;
            item.hours = "영업시간 정보 없음";
            item.lat = null;
            item.lng = null;
        }
    }
}
