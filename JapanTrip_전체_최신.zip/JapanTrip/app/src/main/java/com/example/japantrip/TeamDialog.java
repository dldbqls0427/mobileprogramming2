package com.example.japantrip;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.Map;

/** 팀(함께 가는 친구): 초대 코드 공유, 팀원 목록, 코드로 참여 */
public final class TeamDialog {

    private TeamDialog() { }

    public static void show(final Activity activity) {
        final TripStorage storage = TripStorage.get(activity);

        View v = LayoutInflater.from(activity).inflate(R.layout.dialog_team, null);
        TextView tvCode = v.findViewById(R.id.tv_invite_code);
        TextView hint = v.findViewById(R.id.tv_team_hint);
        LinearLayout membersBox = v.findViewById(R.id.members_container);
        final EditText etCode = v.findViewById(R.id.et_code);

        final String code = storage.inviteCode();
        tvCode.setText(code != null ? code : "------");
        if (!storage.isCloud()) {
            hint.setText("지금은 " + storage.status() + " 상태예요.\n"
                    + "Firebase를 연결하면 친구와 같은 팀으로 일정을 함께 편집할 수 있어요.");
        }

        for (Map.Entry<String, String> m : storage.members().entrySet()) {
            TextView row = new TextView(activity);
            boolean me = m.getKey().equals(storage.myUid()) || "me".equals(m.getKey());
            boolean owner = m.getKey().equals(storage.ownerUid());
            row.setText("• " + m.getValue() + (me ? " (나)" : "") + (owner ? " · 방장" : ""));
            row.setTextSize(14);
            int pad = PlaceViews.dp(activity, 4);
            row.setPadding(0, pad, 0, pad);
            membersBox.addView(row);
        }

        final AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(storage.title() + " 팀")
                .setView(v)
                .setPositiveButton("닫기", null)
                .create();

        v.findViewById(R.id.btn_copy).setOnClickListener(b -> {
            if (code == null) return;
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("초대 코드", code));
            PlaceViews.toast(activity, "초대 코드를 복사했어요");
        });
        v.findViewById(R.id.btn_share).setOnClickListener(b -> {
            if (code == null) return;
            Intent send = new Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "'" + storage.title() + "' 여행 같이 짜자! "
                            + "앱 > My다이어리 > 친구 추가에서 초대 코드 " + code + " 를 입력해줘");
            activity.startActivity(Intent.createChooser(send, "초대 코드 보내기"));
        });
        v.findViewById(R.id.btn_join).setOnClickListener(b -> {
            String input = etCode.getText().toString().trim();
            if (input.length() != 6) {
                PlaceViews.toast(activity, "초대 코드 6자리를 입력하세요");
                return;
            }
            new AlertDialog.Builder(activity)
                    .setMessage("친구 여행에 참여하면 지금 보고 있는 여행에서 나와요. 참여할까요?")
                    .setNegativeButton("취소", null)
                    .setPositiveButton("참여", (d, w) -> storage.joinTrip(input, err -> {
                        if (err != null) {
                            PlaceViews.toast(activity, err);
                            return;
                        }
                        PlaceViews.toast(activity, "친구 팀에 참여했어요! 일정이 곧 바뀌어요");
                        dialog.dismiss();
                    }))
                    .show();
        });

        dialog.show();
    }
}
