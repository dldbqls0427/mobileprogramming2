package com.example.japantrip;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PatternItem;
import com.google.android.gms.maps.model.Dash;
import com.google.android.gms.maps.model.Gap;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.Arrays;
import java.util.List;

/**
 * 화면 4: 여행교통 (길찾기)
 * 앱에 들어 있는 장소(역·맛집·관광지)끼리 이동수단별 예상 시간·요금을 보여줍니다.
 */
public class RouteFragment extends Fragment {

    private static final String ARG_DEST = "dest";
    private static final String[] MODES = {
            RouteEstimator.TRANSIT, RouteEstimator.BUS, RouteEstimator.BIKE, RouteEstimator.WALK};

    private int mode = 0;
    private TextView[] modeChips;
    private EditText etStart, etEnd;
    private GoogleMap map;
    private Place lastFrom, lastTo;

    public static RouteFragment newInstance(@Nullable String destination) {
        RouteFragment f = new RouteFragment();
        Bundle args = new Bundle();
        args.putString(ARG_DEST, destination);
        f.setArguments(args);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_route, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        etStart = v.findViewById(R.id.et_start);
        etEnd = v.findViewById(R.id.et_end);
        PlaceViews.korean(etStart, etEnd);
        etStart.setText("난바역");
        String dest = getArguments() != null ? getArguments().getString(ARG_DEST) : null;
        etEnd.setText(dest != null ? dest : "오사카성");

        v.findViewById(R.id.btn_swap).setOnClickListener(b -> {
            String s = etStart.getText().toString();
            etStart.setText(etEnd.getText());
            etEnd.setText(s);
            search();
        });
        v.findViewById(R.id.btn_clear).setOnClickListener(b -> {
            etStart.setText("");
            etEnd.setText("");
            etStart.requestFocus();
            search();
        });
        TextView.OnEditorActionListener onDone = (tv, actionId, e) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_NEXT
                    || actionId == EditorInfo.IME_ACTION_DONE) {
                if (tv == etEnd) hideKeyboard();
                search();
            }
            return false;
        };
        etStart.setOnEditorActionListener(onDone);
        etEnd.setOnEditorActionListener(onDone);

        modeChips = new TextView[]{
                v.findViewById(R.id.mode_transit),
                v.findViewById(R.id.mode_bus),
                v.findViewById(R.id.mode_bike),
                v.findViewById(R.id.mode_walk)
        };
        for (int i = 0; i < modeChips.length; i++) {
            final int m = i;
            modeChips[i].setOnClickListener(b -> {
                mode = m;
                search();
            });
        }
        // Google 지도 (키가 없으면 그림 지도 그대로)
        boolean hasMap = MapHelper.attach(this, R.id.route_map_area, false, m -> {
            map = m;
            // 위 검색창과 아래 시트에 가리지 않게 여백
            map.setPadding(0, PlaceViews.dp(requireContext(), 110), 0, PlaceViews.dp(requireContext(), 300));
            drawRoute();
        });
        v.findViewById(R.id.route_map).setVisibility(hasMap ? View.GONE : View.VISIBLE);

        search();
    }

    @Override
    public void onDestroyView() {
        map = null;
        super.onDestroyView();
    }

    /** 출발(초록)·도착(빨강) 핀과 점선 연결 */
    private void drawRoute() {
        if (map == null) return;
        map.clear();
        if (lastFrom == null || lastTo == null) {
            MapHelper.fit(map, Arrays.<LatLng>asList(), 0);
            return;
        }
        LatLng a = new LatLng(lastFrom.lat, lastFrom.lng);
        LatLng b = new LatLng(lastTo.lat, lastTo.lng);
        map.addMarker(new MarkerOptions().position(a).title("출발: " + lastFrom.name)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        map.addMarker(new MarkerOptions().position(b).title("도착: " + lastTo.name)
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        List<PatternItem> dashed = Arrays.<PatternItem>asList(new Dash(30), new Gap(18));
        map.addPolyline(new PolylineOptions().add(a, b).color(0xFFE5484D)
                .width(PlaceViews.dp(requireContext(), 4)).pattern(dashed).geodesic(true));
        MapHelper.fit(map, Arrays.asList(a, b), PlaceViews.dp(requireContext(), 60));
    }

    private void search() {
        View v = getView();
        if (v == null) return;
        for (int i = 0; i < modeChips.length; i++) modeChips[i].setSelected(i == mode);

        String start = etStart.getText().toString().trim();
        String end = etEnd.getText().toString().trim();
        TextView summary = v.findViewById(R.id.tv_route_summary);
        LinearLayout list = v.findViewById(R.id.route_list);
        RouteMapView mapView = v.findViewById(R.id.route_map);
        list.removeAllViews();

        lastFrom = null;
        lastTo = null;
        if (TextUtils.isEmpty(start) || TextUtils.isEmpty(end)) {
            summary.setText("시작점과 도착점을 입력하세요");
            mapView.setShowRoute(false);
            drawRoute();
            return;
        }
        Place from = TripRepository.find(start);
        Place to = TripRepository.find(end);
        if (from == null || to == null || !from.hasLocation() || !to.hasLocation()) {
            summary.setText("'" + (from == null ? start : end) + "'의 위치를 몰라요.\n"
                    + "예) 난바역, 우메다역, 신오사카역, 간사이공항, 오사카성, 도톤보리");
            mapView.setShowRoute(false);
            drawRoute();
            return;
        }

        lastFrom = from;
        lastTo = to;
        drawRoute();
        mapView.setShowRoute(true);
        RouteEstimator.Option o = RouteEstimator.estimate(from, to, MODES[mode]);
        summary.setText(start + "  →  " + end + "  · 예상 시간");
        addRow(list, iconFor(o.mode), o.minutes + "분",
                o.summary + " · " + RouteEstimator.distanceText(o.km), o.fare);
    }

    private int iconFor(String mode) {
        if (RouteEstimator.BIKE.equals(mode)) return R.drawable.ic_bike;
        if (RouteEstimator.WALK.equals(mode)) return R.drawable.ic_walk;
        return R.drawable.ic_bus;
    }

    private void addRow(LinearLayout list, int icon, String time, String detail, String fare) {
        View item = LayoutInflater.from(requireContext()).inflate(R.layout.item_route, list, false);
        ((ImageView) item.findViewById(R.id.iv_mode)).setImageResource(icon);
        ((TextView) item.findViewById(R.id.tv_time)).setText(time);
        ((TextView) item.findViewById(R.id.tv_detail)).setText(detail);
        ((TextView) item.findViewById(R.id.tv_fare)).setText(fare);
        list.addView(item);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager)
                requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(etEnd.getWindowToken(), 0);
    }
}
