package com.example.japantrip;

import android.os.Handler;
import android.os.Looper;

import androidx.annotation.Nullable;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Spring Boot 서버와 통신 (회원가입 · 로그인 · 로그아웃).
 * 서버 주소는 local.properties 의 SERVER_URL (기본: 에뮬레이터 → 내 PC = http://10.0.2.2:8080/)
 */
public final class ApiClient {

    /** 결과는 항상 화면(메인) 스레드로 돌아옴. 성공이면 error == null */
    public interface Callback {
        void onResult(@Nullable JSONObject body, @Nullable String error);
    }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private ApiClient() { }

    public static String baseUrl() {
        String u = BuildConfig.SERVER_URL;
        return u.endsWith("/") ? u : u + "/";
    }

    public static void post(String path, @Nullable JSONObject body, @Nullable String token, Callback cb) {
        request("POST", path, body, token, cb);
    }

    public static void get(String path, @Nullable String token, Callback cb) {
        request("GET", path, null, token, cb);
    }

    private static void request(final String method, final String path, @Nullable final JSONObject body,
                                @Nullable final String token, final Callback cb) {
        IO.execute(() -> {
            JSONObject result = null;
            String error = null;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(baseUrl() + path).openConnection();
                c.setRequestMethod(method);
                c.setConnectTimeout(8000);
                c.setReadTimeout(10000);
                c.setRequestProperty("Accept", "application/json");
                if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
                if (body != null) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    try (OutputStream os = c.getOutputStream()) {
                        os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                    }
                }
                int code = c.getResponseCode();
                InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                String text = in == null ? "" : read(in);
                JSONObject json = text.trim().isEmpty() ? new JSONObject() : new JSONObject(text);
                if (code >= 200 && code < 300) {
                    result = json;
                } else {
                    error = json.optString("message", "요청에 실패했어요 (" + code + ")");
                }
            } catch (IOException e) {
                error = "서버에 연결할 수 없어요. 서버가 켜져 있는지 확인해 주세요";
            } catch (JSONException e) {
                error = "서버 응답을 읽지 못했어요";
            } finally {
                if (c != null) c.disconnect();
            }
            final JSONObject r = result;
            final String err = error;
            MAIN.post(() -> cb.onResult(r, err));
        });
    }

    private static String read(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }
}
