package com.example.japantrip;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

/** 회원가입 화면. 가입하면 바로 로그인된 상태로 메인으로 이동 */
public class SignupActivity extends AppCompatActivity {

    private EditText etNickname, etEmail, etPassword, etPassword2;
    private TextView btnSignup;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etNickname = findViewById(R.id.et_nickname);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        etPassword2 = findViewById(R.id.et_password2);
        btnSignup = findViewById(R.id.btn_signup);
        progress = findViewById(R.id.progress);
        PlaceViews.korean(etNickname);

        btnSignup.setOnClickListener(v -> signup());
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
    }

    private void signup() {
        String nickname = etNickname.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        String password2 = etPassword2.getText().toString();

        // 서버에 보내기 전에 한 번 확인 (서버도 다시 확인함)
        if (nickname.isEmpty()) { etNickname.setError("닉네임을 입력해 주세요"); return; }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { etEmail.setError("이메일 형식이 올바르지 않아요"); return; }
        if (password.length() < 6) { etPassword.setError("비밀번호는 6자 이상이에요"); return; }
        if (!password.equals(password2)) { etPassword2.setError("비밀번호가 서로 달라요"); return; }

        JSONObject body = new JSONObject();
        try {
            body.put("nickname", nickname);
            body.put("email", email);
            body.put("password", password);
        } catch (JSONException e) {
            return;
        }
        setLoading(true);
        ApiClient.post("api/auth/signup", body, null, (res, error) -> {
            if (isFinishing()) return;
            setLoading(false);
            if (error != null || res == null) {
                PlaceViews.toast(this, error != null ? error : "회원가입에 실패했어요");
                return;
            }
            PlaceViews.toast(this, nickname + "님, 가입을 환영해요!");
            AuthStore.onLoggedIn(this, res);
        });
    }

    private void setLoading(boolean loading) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnSignup.setEnabled(!loading);
        btnSignup.setAlpha(loading ? 0.5f : 1f);
    }
}
