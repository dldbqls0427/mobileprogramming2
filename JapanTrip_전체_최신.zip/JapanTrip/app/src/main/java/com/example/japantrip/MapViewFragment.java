package com.example.japantrip;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

/**
 * 화면 3: 지도 + 장소 상세
 * - 내 일정에 있는 장소를 날짜별 색깔 핀으로 표시 (day1 빨강, day2 파랑 …)
 * - 지금 보고 있는 장소는 보라 핀
 * - 핀을 누르면 아래 시트가 그 장소로 바뀜
 */
public class MapViewFragment extends Fragment implements TripStorage.Listener {

    private static final String ARG_PLACE = "place";

    private Place place;
    private TripStorage storage;
    private GoogleMap map;

    public static MapViewFragment newInstance(@Nullable Place place) {
        MapViewFragment f = new MapViewFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PLACE, place);
        f.setArguments(args);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_map, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        storage = TripStorage.get(requireContext());
        if (getArguments() != null) place = (Place) getArguments().getSerializable(ARG_PLACE);
        if (place == null) place = firstPlannedPlace();

        v.findViewById(R.id.btn_directions).setOnClickListener(b ->
                ((MainActivity) requireActivity()).openRoute(place.name));
        v.findViewById(R.id.btn_add_to_plan).setOnClickListener(b -> chooseDay());
        addPhotoPlaceholders(v);
        bindSheet();

        boolean hasMap = MapHelper.attach(this, R.id.map_area, false, m -> {
            map = m;
            map.getUiSettings().setZoomControlsEnabled(true);
            // 아래 시트(340dp)에 가리지 않게 지도 아래쪽 여백
            map.setPadding(0, 0, 0, PlaceViews.dp(requireContext(), 340));
            map.setOnMarkerClickListener(this::onMarkerClick);
            drawMarkers();
            focusOnPlace(false);
        });
        v.findViewById(R.id.tv_map_placeholder).setVisibility(hasMap ? View.GONE : View.VISIBLE);

        storage.addListener(this);
    }

    @Override
    public void onDestroyView() {
        storage.removeListener(this);
        map = null;
        super.onDestroyView();
    }

    @Override
    public void onChanged() {
        bindSheet();
        drawMarkers();
    }

    // ---------- 지도 ----------

    private void drawMarkers() {
        if (map == null) return;
        map.clear();
        boolean currentDrawn = false;

        for (int n = 1; n <= storage.dayCount(); n++) {
            String dayKey = TripStorage.dayKey(n);
            for (PlanItem it : storage.items(dayKey)) {
                if (it.isMemo() || !it.hasLocation()) continue;
                boolean isCurrent = it.name.equals(place.name);
                Marker m = map.addMarker(new MarkerOptions()
                        .position(new LatLng(it.lat, it.lng))
                        .title(it.name)
                        .snippet(dayKey + (it.time != null ? " · " + it.time : ""))
                        .icon(isCurrent
                                ? BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)
                                : MapHelper.dayPin(n)));
                if (m != null) m.setTag(it.name);
                if (isCurrent) currentDrawn = true;
            }
        }
        // 일정에 없는 장소를 보고 있으면 그 장소도 핀으로
        if (!currentDrawn && place.hasLocation()) {
            Marker m = map.addMarker(new MarkerOptions()
                    .position(new LatLng(place.lat, place.lng))
                    .title(place.name)
                    .snippet("아직 일정에 없어요")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET)));
            if (m != null) m.setTag(place.name);
        }
    }

    private void focusOnPlace(boolean animate) {
        if (map == null) return;
        LatLng target = place.hasLocation() ? new LatLng(place.lat, place.lng) : MapHelper.OSAKA;
        if (animate) map.animateCamera(CameraUpdateFactory.newLatLngZoom(target, 15f));
        else map.moveCamera(CameraUpdateFactory.newLatLngZoom(target, 15f));
    }

    /** 핀을 누르면 아래 시트를 그 장소로 */
    private boolean onMarkerClick(Marker marker) {
        Object tag = marker.getTag();
        if (tag instanceof String) {
            Place p = TripRepository.find((String) tag);
            if (p == null) p = placeFromPlan((String) tag);
            if (p != null) {
                place = p;
                bindSheet();
                drawMarkers();
            }
        }
        return false; // false: 기본 동작(말풍선 표시 + 카메라 이동)도 함께
    }

    // ---------- 아래 시트 ----------

    private void bindSheet() {
        View v = getView();
        if (v == null) return;
        PlaceViews.bind(v.findViewById(R.id.sheet_content), place);
        String day = storage.dayOf(place.name);
        ((TextView) v.findViewById(R.id.btn_add_to_plan)).setText(
                day == null ? "+ 내 일정에 추가" : "✓ " + day + " 일정에 있어요 (한 번 더 추가)");
    }

    private void addPhotoPlaceholders(View v) {
        LinearLayout photos = v.findViewById(R.id.photo_container);
        for (int i = 0; i < 3; i++) {
            TextView box = new TextView(requireContext());
            box.setBackgroundResource(R.drawable.bg_gray_rounded);
            box.setGravity(Gravity.CENTER);
            box.setTextSize(11);
            box.setText("사진");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    PlaceViews.dp(requireContext(), 104), ViewGroup.LayoutParams.MATCH_PARENT);
            if (i > 0) lp.setMarginStart(PlaceViews.dp(requireContext(), 10));
            photos.addView(box, lp);
        }
    }

    /** 어느 날짜에 넣을지 고르기 */
    private void chooseDay() {
        final int count = storage.dayCount();
        String[] labels = new String[count];
        for (int i = 0; i < count; i++) labels[i] = TripStorage.dayKey(i + 1);
        new AlertDialog.Builder(requireContext())
                .setTitle("'" + place.name + "'을(를) 어느 날에 넣을까요?")
                .setItems(labels, (d, which) -> {
                    String dayKey = TripStorage.dayKey(which + 1);
                    storage.saveItem(dayKey, PlanItem.from(place));
                    PlaceViews.toast(getContext(), dayKey + " 일정에 추가했어요");
                })
                .setNegativeButton("취소", null)
                .show();
    }

    // ---------- 도우미 ----------

    /** 탭을 그냥 눌렀을 때: 일정의 첫 장소, 없으면 몬자야키 */
    private Place firstPlannedPlace() {
        for (int n = 1; n <= storage.dayCount(); n++) {
            for (PlanItem it : storage.items(TripStorage.dayKey(n))) {
                if (!it.isMemo()) return Place.from(it);
            }
        }
        return TripRepository.find("몬자야키");
    }

    @Nullable
    private Place placeFromPlan(String name) {
        for (int n = 1; n <= storage.dayCount(); n++) {
            List<PlanItem> items = storage.items(TripStorage.dayKey(n));
            for (PlanItem it : items) if (!it.isMemo() && it.name.equals(name)) return Place.from(it);
        }
        return null;
    }
}
