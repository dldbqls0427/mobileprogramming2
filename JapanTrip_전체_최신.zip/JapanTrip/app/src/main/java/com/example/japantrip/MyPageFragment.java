package com.example.japantrip;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

/** 화면 5: 마이페이지 (내 이름, 현재 여행, 타임라인, 새 여행) */
public class MyPageFragment extends Fragment implements TripStorage.Listener {

    private TripStorage storage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_mypage, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        storage = TripStorage.get(requireContext());
        final MainActivity main = (MainActivity) requireActivity();

        v.findViewById(R.id.tv_welcome).setOnClickListener(b -> askName());
        v.findViewById(R.id.btn_settings).setOnClickListener(b -> askName());
        v.findViewById(R.id.btn_my_plan).setOnClickListener(b -> main.goToTab(R.id.nav_plan));
        v.findViewById(R.id.btn_team).setOnClickListener(b -> TeamDialog.show(requireActivity()));
        v.findViewById(R.id.tv_trip_title).setOnClickListener(b -> askTitle());
        v.findViewById(R.id.btn_timeline).setOnClickListener(b -> main.openTimeline());
        v.findViewById(R.id.btn_finish_trip).setOnClickListener(b -> {
            if (!storage.isEnded()) storage.setEnded(true);
            main.openTimeline();
        });
        v.findViewById(R.id.btn_new_trip).setOnClickListener(b -> askNewTrip());
        v.findViewById(R.id.btn_logout).setOnClickListener(b -> askLogout());

        storage.addListener(this);
        render();
    }

    @Override
    public void onDestroyView() {
        storage.removeListener(this);
        super.onDestroyView();
    }

    @Override
    public void onChanged() {
        render();
    }

    private void render() {
        View v = getView();
        if (v == null) return;
        ((TextView) v.findViewById(R.id.tv_welcome)).setText(storage.userName() + "님, 환영합니다  ✎");
        String email = AuthStore.email(requireContext());
        ((TextView) v.findViewById(R.id.tv_account)).setText(
                email.isEmpty() ? "" : email + " 계정으로 로그인 중");
        ((TextView) v.findViewById(R.id.tv_trip_count)).setText(
                "현재 여행 · " + storage.dayCount() + "일 · 저장한 장소 " + storage.placeCount() + "곳");
        ((TextView) v.findViewById(R.id.tv_trip_title)).setText(
                storage.title() + (storage.isEnded() ? "  ✓ 완료" : "") + "  ✎");
        int n = storage.memberCount();
        String code = storage.inviteCode();
        ((TextView) v.findViewById(R.id.tv_trip_members)).setText(
                (n > 1 ? "팀 " + n + "명 · " : "솔로 · ") + storage.memberNames()
                        + (code != null ? "\n초대 코드 " + code : "")
                        + "\n" + storage.status());
        ((TextView) v.findViewById(R.id.btn_finish_trip)).setText(
                storage.isEnded() ? "여행 정리 타임라인 보기" : "여행 끝내고 타임라인으로 정리하기");
    }

    private void askName() {
        final EditText et = input(storage.userName(), null);
        new AlertDialog.Builder(requireContext())
                .setTitle("내 이름")
                .setView(pad(et))
                .setNegativeButton("취소", null)
                .setPositiveButton("저장", (d, w) -> {
                    String name = et.getText().toString().trim();
                    if (!name.isEmpty()) storage.setUserName(name);
                })
                .show();
    }

    private void askTitle() {
        final EditText et = input(storage.title(), null);
        new AlertDialog.Builder(requireContext())
                .setTitle("여행 이름")
                .setView(pad(et))
                .setNegativeButton("취소", null)
                .setPositiveButton("저장", (d, w) -> {
                    String t = et.getText().toString().trim();
                    if (!t.isEmpty()) storage.setTitle(t);
                })
                .show();
    }

    private void askNewTrip() {
        final EditText et = input(null, "예) 후쿠오카 먹방 여행");
        new AlertDialog.Builder(requireContext())
                .setTitle("새 여행 만들기")
                .setMessage("지금 여행의 일정이 모두 지워지고 새로 시작해요.")
                .setView(pad(et))
                .setNegativeButton("취소", null)
                .setPositiveButton("새로 시작", (d, w) -> {
                    String t = et.getText().toString().trim();
                    storage.reset(t.isEmpty() ? "새 여행" : t);
                    PlaceViews.toast(getContext(), "새 여행을 시작했어요");
                })
                .show();
    }

    private void askLogout() {
        new AlertDialog.Builder(requireContext())
                .setTitle("로그아웃")
                .setMessage("로그아웃할까요? 다시 쓰려면 로그인해야 해요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("로그아웃", (d, w) -> AuthStore.logout(requireActivity()))
                .show();
    }

    private EditText input(@Nullable String text, @Nullable String hint) {
        EditText et = new EditText(requireContext());
        et.setSingleLine(true);
        if (text != null) et.setText(text);
        if (hint != null) et.setHint(hint);
        PlaceViews.korean(et);
        return et;
    }

    private View pad(View child) {
        FrameLayout wrap = new FrameLayout(requireContext());
        int p = PlaceViews.dp(requireContext(), 20);
        wrap.setPadding(p, p / 2, p, 0);
        wrap.addView(child);
        return wrap;
    }
}
