package com.example.japantrip;

import java.util.ArrayList;
import java.util.List;

/**
 * 앱에 들어 있는 오사카 장소 목록 (맛집 · 관광지 · 역).
 * 홈 추천, 장소 이름 자동 완성(별점·영업시간), 길찾기 거리 계산에 사용합니다.
 */
public final class TripRepository {

    public static final String TAG_FOOD = "맛집";
    public static final String TAG_SIGHT = "관광";

    /** 위치를 모를 때 기준점: 난바역 */
    public static final double BASE_LAT = 34.6664;
    public static final double BASE_LNG = 135.5003;

    private static final List<Place> food = new ArrayList<>();
    private static final List<Place> sight = new ArrayList<>();
    private static final List<Place> stations = new ArrayList<>();

    static {
        // 홈 TOP3 사진이 있는 맛집 (별점 높은 순으로 TOP3에 표시)
        food.add(new Place("엔도 스시", 4.8f, "Open 05:00 ~ 14:00", TAG_FOOD, 34.6838, 135.4797));
        food.add(new Place("규카츠 모토무라 난바점", 4.7f, "Open 11:00 ~ 22:00", TAG_FOOD, 34.6672, 135.5013));
        food.add(new Place("이치란 라멘 도톤보리점", 4.6f, "Open 00:00 ~ 24:00", TAG_FOOD, 34.6687, 135.5019));
        food.add(new Place("쿠시카츠 다루마", 4.4f, "Open 11:00 ~ 22:30", TAG_FOOD, 34.6522, 135.5063));
        food.add(new Place("몬자야키", 4.0f, "Open 10:00 ~ 22:00", TAG_FOOD, 34.6690, 135.5030));
        food.add(new Place("타코야키 와나카", 4.3f, "Open 10:00 ~ 21:00", TAG_FOOD, 34.6655, 135.5040));
        food.add(new Place("551 호라이", 4.2f, "Open 10:00 ~ 21:00", TAG_FOOD, 34.6649, 135.5019));
        food.add(new Place("하브스 케이크", 4.1f, "Open 11:00 ~ 20:00", TAG_FOOD, 34.7030, 135.4980));
        food.add(new Place("키지 오코노미야키", 4.5f, "Open 11:30 ~ 21:30", TAG_FOOD, 34.7054, 135.4896));

        // 홈 TOP3 사진이 있는 관광지
        sight.add(new Place("교토 야사카 거리", 4.8f, "24시간", TAG_SIGHT, 34.9986, 135.7786));
        sight.add(new Place("헵파이브 관람차", 4.7f, "Open 11:00 ~ 23:00", TAG_SIGHT, 34.7038, 135.5005));
        sight.add(new Place("오사카성", 4.0f, "Open 09:00 ~ 17:00", TAG_SIGHT, 34.6873, 135.5262));
        sight.add(new Place("유니버설 스튜디오 재팬", 4.7f, "Open 08:30 ~ 21:00", TAG_SIGHT, 34.6654, 135.4323));
        sight.add(new Place("도톤보리", 4.5f, "24시간", TAG_SIGHT, 34.6687, 135.5013));
        sight.add(new Place("우메다 스카이빌딩", 4.4f, "Open 09:30 ~ 22:30", TAG_SIGHT, 34.7053, 135.4898));
        sight.add(new Place("신세카이", 4.1f, "24시간", TAG_SIGHT, 34.6525, 135.5063));
        sight.add(new Place("가이유칸 수족관", 4.6f, "Open 10:00 ~ 20:00", TAG_SIGHT, 34.6545, 135.4289));
        sight.add(new Place("나카노시마 공원", 4.2f, "24시간", TAG_SIGHT, 34.6928, 135.5068));

        stations.add(new Place("난바역", 0f, "", "역", 34.6664, 135.5003));
        stations.add(new Place("우메다역", 0f, "", "역", 34.7025, 135.4959));
        stations.add(new Place("신오사카역", 0f, "", "역", 34.7334, 135.5002));
        stations.add(new Place("간사이공항", 0f, "", "역", 34.4320, 135.2304));
    }

    public static List<Place> list(String tag) {
        return TAG_FOOD.equals(tag) ? food : sight;
    }

    /** 이름으로 알려진 장소 찾기 (별점/좌표 자동 채우기용) */
    public static Place find(String name) {
        if (name == null) return null;
        String n = name.trim();
        for (Place p : food) if (p.name.equals(n)) return p;
        for (Place p : sight) if (p.name.equals(n)) return p;
        for (Place p : stations) if (p.name.equals(n)) return p;
        return null;
    }

    /** 장소 사진 (res/drawable-nodpi). 사진이 없으면 0 */
    public static int imageFor(String name) {
        if (name == null) return 0;
        switch (name) {
            case "엔도 스시": return R.drawable.food_sushi;
            case "규카츠 모토무라 난바점": return R.drawable.food_gyukatsu;
            case "이치란 라멘 도톤보리점": return R.drawable.food_ramen;
            case "교토 야사카 거리": return R.drawable.sight_yasaka;
            case "헵파이브 관람차": return R.drawable.sight_ferris;
            default: return 0;
        }
    }

    private TripRepository() { }
}
