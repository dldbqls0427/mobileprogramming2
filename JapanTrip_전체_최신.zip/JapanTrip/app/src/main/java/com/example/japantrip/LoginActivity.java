package com.example.japantrip;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

/** 로그인 화면 (앱 첫 화면). 이미 로그인했으면 바로 메인으로 */
public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private TextView btnLogin;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (AuthStore.isLoggedIn(this)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        progress = findViewById(R.id.progress);
        ((TextView) findViewById(R.id.tv_server)).setText("서버 " + ApiClient.baseUrl());

        btnLogin.setOnClickListener(v -> login());
        findViewById(R.id.btn_go_signup).setOnClickListener(v ->
                startActivity(new Intent(this, SignupActivity.class)));
    }

    private void login() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        if (email.isEmpty() || password.isEmpty()) {
            PlaceViews.toast(this, "이메일과 비밀번호를 입력해 주세요");
            return;
        }
        JSONObject body = new JSONObject();
        try {
            body.put("email", email);
            body.put("password", password);
        } catch (JSONException e) {
            return;
        }
        setLoading(true);
        ApiClient.post("api/auth/login", body, null, (res, error) -> {
            if (isFinishing()) return;
            setLoading(false);
            if (error != null || res == null) {
                PlaceViews.toast(this, error != null ? error : "로그인에 실패했어요");
                return;
            }
            PlaceViews.toast(this, "로그인했어요");
            AuthStore.onLoggedIn(this, res);
        });
    }

    private void setLoading(boolean loading) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
        btnLogin.setAlpha(loading ? 0.5f : 1f);
    }
}
