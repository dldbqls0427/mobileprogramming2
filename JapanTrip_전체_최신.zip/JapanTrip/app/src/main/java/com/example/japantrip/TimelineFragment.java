package com.example.japantrip;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.List;

/**
 * 여행 정리 타임라인: 전체 일정을 날짜·시간 순서대로 한 화면에 보여줍니다.
 */
public class TimelineFragment extends Fragment implements TripStorage.Listener {

    private TripStorage storage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_timeline, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        storage = TripStorage.get(requireContext());
        storage.addListener(this);
        render();
    }

    @Override
    public void onDestroyView() {
        storage.removeListener(this);
        super.onDestroyView();
    }

    @Override
    public void onChanged() {
        render();
    }

    private void render() {
        View v = getView();
        if (v == null) return;

        int memos = 0;
        for (int n = 1; n <= storage.dayCount(); n++) {
            for (PlanItem p : storage.items(TripStorage.dayKey(n))) if (p.isMemo()) memos++;
        }

        ((TextView) v.findViewById(R.id.tv_tl_title)).setText(storage.title() + " 타임라인");
        ((TextView) v.findViewById(R.id.tv_tl_status)).setText(storage.isEnded()
                ? "여행 완료 · 전체 코스를 시간 순서대로 정리했어요"
                : "여행 중 · 지금까지의 계획이에요");
        ((TextView) v.findViewById(R.id.stat_days)).setText(storage.dayCount() + "\n일");
        ((TextView) v.findViewById(R.id.stat_places)).setText(storage.placeCount() + "\n장소");
        ((TextView) v.findViewById(R.id.stat_records)).setText(memos + "\n메모");
        ((TextView) v.findViewById(R.id.tv_tl_members)).setText("함께한 사람: " + storage.memberNames());

        TextView endBtn = v.findViewById(R.id.btn_tl_end);
        endBtn.setText(storage.isEnded() ? "다시 '여행 중'으로 바꾸기" : "여행 끝내기 (완료로 표시)");
        endBtn.setOnClickListener(b -> storage.setEnded(!storage.isEnded()));

        LinearLayout container = v.findViewById(R.id.timeline_container);
        container.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(requireContext());

        for (int n = 1; n <= storage.dayCount(); n++) {
            List<PlanItem> items = storage.items(TripStorage.dayKey(n));

            View dayView = inf.inflate(R.layout.item_timeline_day, container, false);
            ((TextView) dayView.findViewById(R.id.tv_day_label)).setText("DAY " + n);
            ((TextView) dayView.findViewById(R.id.tv_course)).setText(course(items));
            LinearLayout entries = dayView.findViewById(R.id.entries_container);
            for (int i = 0; i < items.size(); i++) {
                entries.addView(entry(inf, entries, items.get(i), i == items.size() - 1));
            }
            container.addView(dayView);
        }
    }

    /** "몬자야키 → 오사카성" */
    private String course(List<PlanItem> items) {
        StringBuilder sb = new StringBuilder();
        for (PlanItem p : items) {
            if (p.isMemo()) continue;
            if (sb.length() > 0) sb.append("  →  ");
            sb.append(p.name);
        }
        return sb.length() == 0 ? "아직 일정이 없어요" : sb.toString();
    }

    private View entry(LayoutInflater inf, ViewGroup parent, PlanItem it, boolean last) {
        View row = inf.inflate(R.layout.item_timeline_entry, parent, false);
        ((TextView) row.findViewById(R.id.tv_entry_time)).setText(it.time != null ? it.time : "");
        ((TextView) row.findViewById(R.id.tv_entry_name)).setText(it.isMemo() ? "📝 " + it.name : it.name);

        TextView note = row.findViewById(R.id.tv_entry_note);
        if (it.note != null && !it.note.isEmpty()) {
            note.setVisibility(View.VISIBLE);
            note.setText(it.note);
        }
        String who = storage.isCloud() && it.authorName != null ? it.authorName + "님이 계획" : "";
        String rating = it.isMemo() ? "" : PlaceViews.rating(it.rating);
        ((TextView) row.findViewById(R.id.tv_entry_author)).setText(
                rating + (!rating.isEmpty() && !who.isEmpty() ? " · " : "") + who);

        if (it.isMemo()) row.findViewById(R.id.tl_dot).setBackgroundResource(R.drawable.bg_tl_dot_memo);
        if (last) row.findViewById(R.id.tl_line).setVisibility(View.INVISIBLE);
        return row;
    }
}
