package com.example.japantrip;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

/** 날짜별 일정 한 칸 (장소 또는 메모) */
public class PlanItem {
    public static final String TYPE_PLACE = "place";
    public static final String TYPE_MEMO = "memo";

    public String id;
    public String type = TYPE_PLACE;
    public String name;          // 장소 이름 또는 메모 내용
    public double rating;
    public String hours;
    public String time;          // "10:30" 형식, 없으면 null
    public String note;          // 장소에 붙이는 짧은 메모
    public Double lat;
    public Double lng;
    public long order;
    public String authorUid;     // 누가 추가/수정했는지 (Firebase 모드)
    public String authorName;

    public static PlanItem place(String name, double rating, String hours, Double lat, Double lng) {
        PlanItem p = new PlanItem();
        p.type = TYPE_PLACE;
        p.name = name;
        p.rating = rating;
        p.hours = hours;
        p.lat = lat;
        p.lng = lng;
        p.order = System.currentTimeMillis();
        return p;
    }

    public static PlanItem memo(String text) {
        PlanItem p = new PlanItem();
        p.type = TYPE_MEMO;
        p.name = text;
        p.order = System.currentTimeMillis();
        return p;
    }

    public static PlanItem from(Place place) {
        return place(place.name, place.rating, place.hours, place.lat, place.lng);
    }

    public boolean isMemo() {
        return TYPE_MEMO.equals(type);
    }

    public boolean hasLocation() {
        return lat != null && lng != null;
    }

    // ---------- 폰에 저장하기 위한 JSON 변환 ----------

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("type", type);
        o.put("name", name);
        o.put("rating", rating);
        o.putOpt("hours", hours);
        o.putOpt("time", time);
        o.putOpt("note", note);
        o.putOpt("lat", lat);
        o.putOpt("lng", lng);
        o.put("order", order);
        o.putOpt("authorUid", authorUid);
        o.putOpt("authorName", authorName);
        return o;
    }

    public static PlanItem fromJson(JSONObject o) {
        PlanItem p = new PlanItem();
        p.id = o.optString("id", null);
        p.type = o.optString("type", TYPE_PLACE);
        p.name = o.optString("name", "");
        p.rating = o.optDouble("rating", 0);
        p.hours = o.has("hours") ? o.optString("hours") : null;
        p.time = o.has("time") ? o.optString("time") : null;
        p.note = o.has("note") ? o.optString("note") : null;
        p.lat = o.has("lat") ? o.optDouble("lat") : null;
        p.lng = o.has("lng") ? o.optDouble("lng") : null;
        p.order = o.optLong("order", 0);
        p.authorUid = o.has("authorUid") ? o.optString("authorUid") : null;
        p.authorName = o.has("authorName") ? o.optString("authorName") : null;
        return p;
    }

    // ---------- Firebase 실시간 DB 저장용 Map 변환 ----------

    public Map<String, Object> toMap() {
        Map<String, Object> m = new HashMap<>();
        m.put("type", type);
        m.put("name", name);
        m.put("rating", rating);
        m.put("hours", hours);
        m.put("time", time);
        m.put("note", note);
        m.put("lat", lat);
        m.put("lng", lng);
        m.put("order", order);
        m.put("authorUid", authorUid);
        m.put("authorName", authorName);
        return m;
    }

    public static PlanItem fromMap(String id, Map<?, ?> m) {
        PlanItem p = new PlanItem();
        p.id = id;
        p.type = str(m.get("type"), TYPE_PLACE);
        p.name = str(m.get("name"), "");
        p.rating = num(m.get("rating"), 0);
        p.hours = str(m.get("hours"), null);
        p.time = str(m.get("time"), null);
        p.note = str(m.get("note"), null);
        p.lat = m.get("lat") instanceof Number ? ((Number) m.get("lat")).doubleValue() : null;
        p.lng = m.get("lng") instanceof Number ? ((Number) m.get("lng")).doubleValue() : null;
        p.order = (long) num(m.get("order"), 0);
        p.authorUid = str(m.get("authorUid"), null);
        p.authorName = str(m.get("authorName"), null);
        return p;
    }

    private static String str(Object o, String def) {
        return o instanceof String ? (String) o : def;
    }

    private static double num(Object o, double def) {
        return o instanceof Number ? ((Number) o).doubleValue() : def;
    }

    /** 시간 있는 것 먼저(시간순), 그다음 추가한 순서 */
    public static final Comparator<PlanItem> ORDER = new Comparator<PlanItem>() {
        @Override
        public int compare(PlanItem a, PlanItem b) {
            boolean at = a.time != null && !a.time.isEmpty();
            boolean bt = b.time != null && !b.time.isEmpty();
            if (at && bt) {
                int c = a.time.compareTo(b.time);
                if (c != 0) return c;
            } else if (at != bt) {
                return at ? -1 : 1;
            }
            return Long.compare(a.order, b.order);
        }
    };
}
