package com.example.japantrip;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 화면 1: 홈
 * 해시태그(#맛집/#관광)를 고르면 평점순 TOP3 와 더 추천할 장소를 보여줍니다.
 * (나중에 서버를 붙이면 Spring Boot 추천 결과로 바꿀 수 있어요)
 */
public class HomeFragment extends Fragment {

    /** 광고·스폰서 배너 사진 (res/drawable-nodpi, 1080 x 580) */
    private static final int[] BANNERS = {
            R.drawable.banner_1,
            R.drawable.banner_2
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int bannerIndex = 0;
    private TextView tvBanner, tvBannerIndex, chipFood, chipSight;
    private ImageView ivBanner;
    private boolean liked = false;
    private String currentTag = TripRepository.TAG_FOOD;

    private final Runnable bannerTick = new Runnable() {
        @Override
        public void run() {
            showBanner(bannerIndex + 1);
            handler.postDelayed(this, 3500);
        }
    };

    /** 추천 한 줄에 필요한 값 */
    private static class Rec {
        Place place;
        String reason;

        Rec(Place p, String r) {
            place = p;
            reason = r;
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        tvBanner = v.findViewById(R.id.tv_banner);
        ivBanner = v.findViewById(R.id.iv_banner);
        tvBanner.setVisibility(View.GONE); // 배너 사진 안에 글씨가 있어서 숨김
        tvBannerIndex = v.findViewById(R.id.tv_banner_index);
        v.findViewById(R.id.banner).setOnClickListener(b -> showBanner(bannerIndex + 1));
        showBanner(0);

        chipFood = v.findViewById(R.id.chip_food);
        chipSight = v.findViewById(R.id.chip_sight);
        chipFood.setOnClickListener(b -> selectTag(TripRepository.TAG_FOOD));
        chipSight.setOnClickListener(b -> selectTag(TripRepository.TAG_SIGHT));
        selectTag(TripRepository.TAG_FOOD);

        v.findViewById(R.id.card_short).setOnClickListener(b ->
                PlaceViews.toast(getContext(), "숏 동영상 재생 (준비 중)"));

        final ImageView like = v.findViewById(R.id.btn_like);
        final TextView likeCount = v.findViewById(R.id.tv_like_count);
        like.setOnClickListener(b -> {
            liked = !liked;
            like.setColorFilter(liked ? 0xFFE5484D : 0xFF000000);
            likeCount.setText(liked ? "좋아요 129개" : "좋아요 128개");
        });

        v.findViewById(R.id.btn_edit).setOnClickListener(b ->
                ((MainActivity) requireActivity()).goToTab(R.id.nav_plan));
        v.findViewById(R.id.btn_more).setOnClickListener(b ->
                ((MainActivity) requireActivity()).goToTab(R.id.nav_profile));
    }

    @Override
    public void onResume() {
        super.onResume();
        handler.postDelayed(bannerTick, 3500);
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(bannerTick);
    }

    private void showBanner(int index) {
        bannerIndex = index % BANNERS.length;
        ivBanner.setImageResource(BANNERS[bannerIndex]);
        tvBannerIndex.setText((bannerIndex + 1) + " / " + BANNERS.length);
    }

    private void selectTag(final String tag) {
        currentTag = tag;
        chipFood.setSelected(TripRepository.TAG_FOOD.equals(tag));
        chipSight.setSelected(TripRepository.TAG_SIGHT.equals(tag));

        // 평점 높은 순으로 정렬해서 TOP3 + 나머지 추천
        List<Place> sorted = new ArrayList<>(TripRepository.list(tag));
        Collections.sort(sorted, (a, b) -> Float.compare(b.rating, a.rating));
        List<Rec> recs = new ArrayList<>();
        for (Place p : sorted) {
            boolean inPlan = TripStorage.get(requireContext()).dayOf(p.name) != null;
            recs.add(new Rec(p, PlaceViews.rating(p.rating) + (inPlan ? "  · 내 일정에 있음" : "")));
        }
        render(tag, recs);
    }

    private void render(String tag, List<Rec> recs) {
        View v = getView();
        if (v == null) return;
        ((TextView) v.findViewById(R.id.tv_rank_title)).setText(
                "#" + tag + " TOP 3");
        ((TextView) v.findViewById(R.id.tv_more_title)).setText("#" + tag + " 더 추천해요");

        LayoutInflater inf = LayoutInflater.from(requireContext());
        LinearLayout rank = v.findViewById(R.id.rank_container);
        LinearLayout more = v.findViewById(R.id.more_container);
        rank.removeAllViews();
        more.removeAllViews();

        for (int i = 0; i < recs.size(); i++) {
            final Rec r = recs.get(i);
            if (i < 3) {
                View item = inf.inflate(R.layout.item_rank, rank, false);
                TextView tvRank = item.findViewById(R.id.tv_rank);
                tvRank.setText(String.valueOf(i + 1));
                View thumb = item.findViewById(R.id.thumb);
                if (i == 0) thumb.setBackgroundResource(R.drawable.bg_pink_rounded);
                int photo = TripRepository.imageFor(r.place.name);
                if (photo != 0) {
                    // 사진을 칸에 꽉 채우고, 순위 숫자는 왼쪽 위 작은 동그라미로
                    ImageView iv = item.findViewById(R.id.iv_thumb);
                    iv.setImageResource(photo);
                    iv.setVisibility(View.VISIBLE);
                    thumb.setClipToOutline(true); // 둥근 모서리 유지
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                            PlaceViews.dp(requireContext(), 18), PlaceViews.dp(requireContext(), 18),
                            Gravity.TOP | Gravity.START);
                    lp.setMargins(PlaceViews.dp(requireContext(), 3), PlaceViews.dp(requireContext(), 3), 0, 0);
                    tvRank.setLayoutParams(lp);
                    tvRank.setGravity(Gravity.CENTER);
                    tvRank.setTextSize(11);
                    tvRank.setBackgroundResource(R.drawable.bg_rank_badge);
                }
                ((TextView) item.findViewById(R.id.tv_name)).setText(r.place.name);
                ((TextView) item.findViewById(R.id.tv_rating)).setText(r.reason);
                item.setOnClickListener(b -> ((MainActivity) requireActivity()).showPlaceOnMap(r.place));
                rank.addView(item);
            } else {
                View item = inf.inflate(R.layout.item_recommend, more, false);
                ((TextView) item.findViewById(R.id.tv_name)).setText(r.place.name);
                ((TextView) item.findViewById(R.id.tv_tag)).setText("#" + tag + "  ★" + r.place.rating);
                int photo = TripRepository.imageFor(r.place.name);
                if (photo != 0) {
                    ImageView iv = item.findViewById(R.id.iv_photo);
                    iv.setImageResource(photo);
                    iv.setClipToOutline(true);
                }
                item.setOnClickListener(b -> ((MainActivity) requireActivity()).showPlaceOnMap(r.place));
                more.addView(item);
            }
        }
    }
}
