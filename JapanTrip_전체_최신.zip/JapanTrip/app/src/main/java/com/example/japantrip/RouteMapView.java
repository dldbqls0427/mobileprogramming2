package com.example.japantrip;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * 시안 4번처럼 보이게 그린 가짜 지도.
 * 실제 지도는 Google Maps SDK(MapView)로 교체하면 됩니다.
 */
public class RouteMapView extends View {

    private final Paint land = new Paint();
    private final Paint water = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint road = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint route = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean showRoute = true;

    public RouteMapView(Context c, @Nullable AttributeSet a) {
        super(c, a);
        float d = getResources().getDisplayMetrics().density;
        land.setColor(0xFFEEF1F4);
        water.setColor(0xFFAAD7F0);
        road.setColor(0xFFFFFFFF);
        road.setStrokeWidth(5 * d);
        route.setColor(0xFFE5484D);
        route.setStyle(Paint.Style.STROKE);
        route.setStrokeWidth(5 * d);
        route.setStrokeJoin(Paint.Join.ROUND);
        route.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setShowRoute(boolean show) {
        showRoute = show;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, land);

        // 강
        Path river = new Path();
        river.moveTo(0, h * 0.18f);
        river.cubicTo(w * 0.25f, h * 0.12f, w * 0.15f, h * 0.35f, 0, h * 0.42f);
        river.close();
        c.drawPath(river, water);

        // 도로 격자
        for (float x = w * 0.08f; x < w; x += w * 0.17f) c.drawLine(x, 0, x + w * 0.05f, h, road);
        for (float y = h * 0.1f; y < h; y += h * 0.11f) c.drawLine(0, y, w, y - h * 0.03f, road);

        if (!showRoute) return;

        float d = getResources().getDisplayMetrics().density;
        float sx = w * 0.42f, sy = h * 0.52f;   // 출발
        float ex = w * 0.75f, ey = h * 0.17f;   // 도착
        Path p = new Path();
        p.moveTo(sx, sy);
        p.lineTo(w * 0.55f, sy);
        p.lineTo(w * 0.55f, h * 0.38f);
        p.lineTo(w * 0.68f, h * 0.38f);
        p.lineTo(w * 0.68f, ey);
        p.lineTo(ex, ey);
        c.drawPath(p, route);

        dot.setColor(0xFFFFFFFF);
        c.drawCircle(sx, sy, 9 * d, dot);
        c.drawCircle(ex, ey, 9 * d, dot);
        dot.setColor(0xFF2EC27E);
        c.drawCircle(sx, sy, 6 * d, dot);
        dot.setColor(0xFFE5484D);
        c.drawCircle(ex, ey, 6 * d, dot);
    }
}
