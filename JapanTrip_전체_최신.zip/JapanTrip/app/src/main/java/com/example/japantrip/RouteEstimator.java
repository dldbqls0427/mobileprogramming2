package com.example.japantrip;

import java.util.Locale;

/**
 * 두 장소 사이 이동 시간·요금 예상 (인터넷 없이 계산).
 * 직선거리 × 1.3(도로 우회) 에 이동수단별 평균 속도·대기시간·요금(오사카 기준 대략값)을 적용합니다.
 * 나중에 서버/Google 경로 API로 바꿀 수 있어요.
 */
public final class RouteEstimator {

    public static final String TRANSIT = "transit", BUS = "bus", BIKE = "bike", WALK = "walk";

    public static class Option {
        public final String mode;
        public final int minutes;
        public final double km;
        public final String summary;
        public final String fare;

        Option(String mode, int minutes, double km, String summary, String fare) {
            this.mode = mode;
            this.minutes = minutes;
            this.km = km;
            this.summary = summary;
            this.fare = fare;
        }
    }

    private RouteEstimator() { }

    /** 두 지점 사이 직선거리(km) */
    public static double km(double lat1, double lng1, double lat2, double lng2) {
        double r = 6371.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return 2 * r * Math.asin(Math.sqrt(a));
    }

    public static Option estimate(Place from, Place to, String mode) {
        double road = km(from.lat, from.lng, to.lat, to.lng) * 1.3;
        double d = Math.round(road * 10) / 10.0;
        switch (mode) {
            case BUS:
                return new Option(BUS, minutes(road, 15, 6), d, "시영버스 · 도보 포함", "¥210");
            case BIKE: {
                int min = minutes(road, 13, 2);
                int fare = 165 * (int) Math.ceil(min / 30.0);   // 공유자전거 30분 단위
                return new Option(BIKE, min, d, "공유자전거", "¥" + fare);
            }
            case WALK:
                return new Option(WALK, minutes(road, 4.5, 0), d, "도보", "무료");
            default: {
                int fare = 190 + 50 * (int) Math.floor(Math.max(0, road - 3) / 3);
                return new Option(TRANSIT, minutes(road, 28, 8), d, "지하철 · 도보 포함",
                        "¥" + Math.min(fare, 390));
            }
        }
    }

    public static String distanceText(double km) {
        return String.format(Locale.US, "%.1fkm", km);
    }

    private static int minutes(double km, double kmh, int extraMin) {
        return Math.max(1, (int) Math.round(km / kmh * 60) + extraMin);
    }
}
