package com.example.japantrip;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.annotation.Nullable;

import org.json.JSONObject;

/** 로그인 상태 저장 (토큰 · 이메일 · 닉네임). 앱을 껐다 켜도 로그인 유지 */
public final class AuthStore {

    private static final String PREFS = "auth";

    private AuthStore() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isLoggedIn(Context c) {
        return token(c) != null;
    }

    @Nullable
    public static String token(Context c) {
        return prefs(c).getString("token", null);
    }

    public static String email(Context c) {
        return prefs(c).getString("email", "");
    }

    public static String nickname(Context c) {
        return prefs(c).getString("nickname", "");
    }

    public static void clear(Context c) {
        prefs(c).edit().clear().apply();
    }

    /**
     * 로그인 · 회원가입 성공 응답 {"token": "...", "user": {"email", "nickname"}} 을 저장하고
     * 메인 화면으로 이동 (뒤로 가기로 로그인 화면에 돌아오지 않게)
     */
    public static void onLoggedIn(Activity a, JSONObject res) {
        JSONObject user = res.optJSONObject("user");
        String nickname = user != null ? user.optString("nickname", "") : "";
        prefs(a).edit()
                .putString("token", res.optString("token"))
                .putString("email", user != null ? user.optString("email", "") : "")
                .putString("nickname", nickname)
                .apply();
        if (!nickname.isEmpty()) TripStorage.get(a).setUserName(nickname);

        Intent i = new Intent(a, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        a.startActivity(i);
        a.finish();
    }

    /** 로그아웃: 서버의 토큰을 지우고(실패해도 진행) 로그인 화면으로 */
    public static void logout(final Activity a) {
        String token = token(a);
        clear(a);
        if (token != null) {
            ApiClient.post("api/auth/logout", null, token, (body, error) -> { });
        }
        Intent i = new Intent(a, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        a.startActivity(i);
        a.finish();
    }
}
