package com.example.japantrip;

import android.text.TextUtils;

import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import java.util.List;

/**
 * Google 지도 공통 도우미.
 * local.properties 에 MAPS_API_KEY 가 없으면 지도를 만들지 않고 회색 칸을 그대로 둡니다.
 */
public final class MapHelper {

    /** 위치를 모를 때 기준점: 난바역 */
    public static final LatLng OSAKA = new LatLng(34.6664, 135.5003);

    /** 날짜별 핀 색 (day1 빨강, day2 파랑, day3 초록 …) */
    private static final float[] DAY_HUES = {
            BitmapDescriptorFactory.HUE_RED,
            BitmapDescriptorFactory.HUE_AZURE,
            BitmapDescriptorFactory.HUE_GREEN,
            BitmapDescriptorFactory.HUE_ORANGE,
            BitmapDescriptorFactory.HUE_VIOLET,
            BitmapDescriptorFactory.HUE_YELLOW,
    };

    /** 날짜별 선 색 (핀 색과 맞춤) */
    private static final int[] DAY_COLORS = {
            0xFFE5484D, 0xFF2F80ED, 0xFF2EC27E, 0xFFF2994A, 0xFF9B51E0, 0xFFE2B93B,
    };

    private MapHelper() { }

    public static boolean hasKey() {
        return !TextUtils.isEmpty(BuildConfig.MAPS_API_KEY);
    }

    /**
     * containerId 자리에 지도를 넣고, 준비되면 callback 호출.
     * @param lite true 면 가벼운 정지 지도 (목록 안 미리보기용)
     * @return 지도를 만들었으면 true (키가 없으면 false)
     */
    public static boolean attach(Fragment host, int containerId, boolean lite, OnMapReadyCallback callback) {
        if (!hasKey()) return false;
        GoogleMapOptions options = new GoogleMapOptions()
                .liteMode(lite)
                .mapToolbarEnabled(false)
                .camera(new com.google.android.gms.maps.model.CameraPosition(OSAKA, 13f, 0f, 0f));
        SupportMapFragment mf = SupportMapFragment.newInstance(options);
        host.getChildFragmentManager().beginTransaction().replace(containerId, mf).commitNow();
        mf.getMapAsync(callback);
        return true;
    }

    public static BitmapDescriptor dayPin(int dayNumber) {
        return BitmapDescriptorFactory.defaultMarker(DAY_HUES[(dayNumber - 1) % DAY_HUES.length]);
    }

    public static int dayColor(int dayNumber) {
        return DAY_COLORS[(dayNumber - 1) % DAY_COLORS.length];
    }

    /** 점들이 모두 보이게 카메라 맞추기 */
    public static void fit(GoogleMap map, List<LatLng> points, int paddingPx) {
        if (points.isEmpty()) {
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(OSAKA, 13f));
        } else if (points.size() == 1) {
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(points.get(0), 15f));
        } else {
            LatLngBounds.Builder b = LatLngBounds.builder();
            for (LatLng p : points) b.include(p);
            try {
                map.moveCamera(CameraUpdateFactory.newLatLngBounds(b.build(), paddingPx));
            } catch (IllegalStateException e) {
                // 지도 크기가 아직 0일 때: 중심만 맞춤
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(b.build().getCenter(), 12f));
            }
        }
    }
}
