package com.example.japantrip;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * 여행 일정 저장소. 화면 코드는 이 클래스의 메서드만 사용합니다.
 *
 * [혼자 모드]  google-services.json 이 없을 때
 *   → 폰(SharedPreferences)에만 저장
 *
 * [팀 모드]    Firebase 연결됨
 *   → Firebase 실시간 DB에 저장. 같은 팀원이 바꾸면 모든 폰에 바로 반영.
 *   → 오프라인에서 고친 내용은 연결되면 자동으로 올라감.
 *
 * Firebase 데이터 구조
 *   trips/{tripId}                    title, inviteCode, ownerUid, dayCount, ended, members/{uid}=이름
 *   invites/{초대코드}                 tripId
 *   tripDays/{tripId}/{day1}/{itemId}  일정 한 칸 (PlanItem)
 *   activity/{tripId}/{pushId}        누가 무엇을 했는지 (알림용)
 */
public final class TripStorage {

    /** 일정이 바뀌면 호출 */
    public interface Listener {
        void onChanged();
    }

    /** 친구가 무언가를 했을 때 (알림용) */
    public interface ActivityListener {
        void onActivity(String who, String message);
    }

    /** 성공하면 error == null */
    public interface Result {
        void done(@Nullable String error);
    }

    private static TripStorage instance;

    private final SharedPreferences prefs;
    private final List<Listener> listeners = new ArrayList<>();
    private final List<ActivityListener> activityListeners = new ArrayList<>();

    // ----- 현재 여행 (혼자/팀 공통) -----
    private String title = "일본여행";
    private String userName = "여행자";
    private int dayCount = 2;
    private boolean ended = false;
    /** dayKey("day1") -> 그날 일정 */
    private Map<String, List<PlanItem>> days = new LinkedHashMap<>();

    // ----- 팀 모드 (Firebase) -----
    private FirebaseDatabase db;
    private FirebaseAuth auth;
    private String uid;
    private String tripId;
    private String inviteCode;
    private String ownerUid;
    private final Map<String, String> members = new LinkedHashMap<>();
    private String status = "혼자 모드";
    /** 저장된 여행을 못 불러왔을 때 새로 만드는 건 한 번만 (규칙이 잘못됐을 때 무한 반복 방지) */
    private boolean recreatedOnce = false;

    private DatabaseReference tripRef, daysRef;
    private ValueEventListener tripListener, daysListener;
    private Query activityQuery;
    private ChildEventListener activityChildListener;

    public static synchronized TripStorage get(Context ctx) {
        if (instance == null) instance = new TripStorage(ctx.getApplicationContext());
        return instance;
    }

    private TripStorage(Context ctx) {
        prefs = ctx.getSharedPreferences("trip", Context.MODE_PRIVATE);
        String json = prefs.getString("data", null);
        if (json == null) {
            seedSample();
            save();
        } else {
            load(json);
        }
        initFirebase(ctx);
    }

    // =====================================================================
    // 읽기
    // =====================================================================

    public String title() { return title; }
    public String userName() { return userName; }
    public int dayCount() { return dayCount; }
    public boolean isEnded() { return ended; }

    /** Firebase 팀 모드로 동기화 중인지 */
    public boolean isCloud() { return uid != null && tripId != null; }

    /** "실시간 동기화 중" / "혼자 모드 (Firebase 미연결)" 등 */
    public String status() { return status; }

    @Nullable public String inviteCode() { return isCloud() ? inviteCode : null; }
    @Nullable public String myUid() { return uid; }
    @Nullable public String ownerUid() { return ownerUid; }

    /** uid -> 이름 (혼자 모드면 나만) */
    public Map<String, String> members() {
        if (!isCloud() || members.isEmpty()) {
            Map<String, String> me = new LinkedHashMap<>();
            me.put(uid != null ? uid : "me", userName);
            return me;
        }
        return new LinkedHashMap<>(members);
    }

    public int memberCount() { return members().size(); }

    public String memberNames() {
        StringBuilder sb = new StringBuilder();
        for (String n : members().values()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(n);
        }
        return sb.toString();
    }

    public static String dayKey(int n) {
        return "day" + n;
    }

    /** 정렬된 복사본 */
    public List<PlanItem> items(String dayKey) {
        List<PlanItem> list = days.get(dayKey);
        if (list == null) return new ArrayList<>();
        List<PlanItem> copy = new ArrayList<>(list);
        Collections.sort(copy, PlanItem.ORDER);
        return copy;
    }

    public int placeCount() {
        int c = 0;
        for (int n = 1; n <= dayCount; n++) for (PlanItem p : items(dayKey(n))) if (!p.isMemo()) c++;
        return c;
    }

    /** 이 장소가 일정에 들어 있으면 그 날짜(dayKey), 없으면 null */
    public String dayOf(String placeName) {
        for (int n = 1; n <= dayCount; n++) {
            for (PlanItem p : items(dayKey(n))) {
                if (!p.isMemo() && p.name.equals(placeName)) return dayKey(n);
            }
        }
        return null;
    }

    /** 내가 쓴 항목인지 */
    public boolean isMine(PlanItem item) {
        return item.authorUid == null || item.authorUid.equals(uid);
    }

    // =====================================================================
    // 쓰기 (팀 모드면 Firebase, 아니면 폰에 저장)
    // =====================================================================

    /** item.id 가 없으면 추가, 있으면 수정 */
    public void saveItem(String dayKey, PlanItem item) {
        boolean isNew = item.id == null;
        item.authorUid = uid;
        item.authorName = userName;

        if (isCloud()) {
            DatabaseReference ref = daysRef.child(dayKey);
            if (isNew) item.id = ref.push().getKey();
            ref.child(item.id).setValue(item.toMap());
            String what = item.isMemo() ? "메모" : "'" + item.name + "'";
            logActivity(dayKey + "에 " + what + (isNew ? "를 추가했어요" : "를 수정했어요"));
            return;
        }

        List<PlanItem> list = days.get(dayKey);
        if (list == null) {
            list = new ArrayList<>();
            days.put(dayKey, list);
        }
        if (isNew) {
            item.id = UUID.randomUUID().toString();
            list.add(item);
        } else {
            boolean found = false;
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i).id.equals(item.id)) {
                    list.set(i, item);
                    found = true;
                }
            }
            if (!found) list.add(item);
        }
        changed();
    }

    public void deleteItem(String dayKey, PlanItem item) {
        if (isCloud()) {
            daysRef.child(dayKey).child(item.id).removeValue();
            logActivity(dayKey + "에서 " + (item.isMemo() ? "메모" : "'" + item.name + "'") + "를 삭제했어요");
            return;
        }
        List<PlanItem> list = days.get(dayKey);
        if (list == null) return;
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).id.equals(item.id)) list.remove(i);
        }
        changed();
    }

    public void addDay() {
        if (isCloud()) {
            // 두 명이 동시에 눌러도 정확히 +1 되도록 트랜잭션
            tripRef.child("dayCount").runTransaction(new Transaction.Handler() {
                @NonNull
                @Override
                public Transaction.Result doTransaction(@NonNull MutableData data) {
                    Object v = data.getValue();
                    int cur = v instanceof Number ? ((Number) v).intValue() : 2;
                    data.setValue(cur + 1);
                    return Transaction.success(data);
                }

                @Override
                public void onComplete(@Nullable DatabaseError e, boolean committed, @Nullable DataSnapshot s) {
                    if (committed && s != null && s.getValue() instanceof Number) {
                        logActivity("day" + ((Number) s.getValue()).intValue() + "를 추가했어요");
                    }
                }
            });
            return;
        }
        dayCount++;
        changed();
    }

    /** 마지막 날짜 삭제 (그날 일정도 함께) */
    public void removeLastDay() {
        if (dayCount <= 1) return;
        int last = dayCount;
        if (isCloud()) {
            Map<String, Object> up = new HashMap<>();
            up.put("trips/" + tripId + "/dayCount", last - 1);
            up.put("tripDays/" + tripId + "/" + dayKey(last), null);
            db.getReference().updateChildren(up);
            logActivity("day" + last + "를 삭제했어요");
            return;
        }
        days.remove(dayKey(last));
        dayCount--;
        changed();
    }

    public void setTitle(String t) {
        if (isCloud()) {
            tripRef.child("title").setValue(t);
            logActivity("여행 이름을 '" + t + "'(으)로 바꿨어요");
            return;
        }
        title = t;
        changed();
    }

    public void setUserName(String n) {
        userName = n;
        if (isCloud()) tripRef.child("members").child(uid).setValue(n);
        changed();
    }

    public void setEnded(boolean e) {
        if (isCloud()) {
            tripRef.child("ended").setValue(e);
            if (e) logActivity("여행을 마치고 타임라인으로 정리했어요");
            return;
        }
        ended = e;
        changed();
    }

    /** 새 여행 시작. 팀 모드면 새 팀(새 초대 코드)이 만들어지고 지금 팀에서는 빠져요. */
    public void reset(String newTitle) {
        if (isCloud()) {
            days = new LinkedHashMap<>();
            dayCount = 2;
            ended = false;
            title = newTitle;
            createCloudTrip(false, null);
            return;
        }
        title = newTitle;
        dayCount = 2;
        ended = false;
        days.clear();
        changed();
    }

    // =====================================================================
    // 팀: 초대 코드로 참여
    // =====================================================================

    public void joinTrip(String code, final Result cb) {
        if (!isCloud()) {
            cb.done("Firebase에 연결된 다음에 참여할 수 있어요 (" + status + ")");
            return;
        }
        final String c = code.trim().toUpperCase();
        db.getReference("invites").child(c).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snap) {
                final Object v = snap.getValue();
                if (!(v instanceof String)) {
                    cb.done("초대 코드 '" + c + "'를 찾을 수 없어요");
                    return;
                }
                final String id = (String) v;
                if (id.equals(tripId)) {
                    cb.done("이미 이 여행의 팀원이에요");
                    return;
                }
                db.getReference("trips").child(id).child("members").child(uid).setValue(userName)
                        .addOnCompleteListener(t -> {
                            if (!t.isSuccessful()) {
                                cb.done("참여하지 못했어요: " + msg(t.getException()));
                                return;
                            }
                            subscribe(id);
                            logActivity("팀에 참여했어요");
                            cb.done(null);
                        });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) {
                cb.done("초대 코드를 확인하지 못했어요: " + e.getMessage());
            }
        });
    }

    // =====================================================================
    // 리스너
    // =====================================================================

    public void addListener(Listener l) { listeners.add(l); }
    public void removeListener(Listener l) { listeners.remove(l); }
    public void addActivityListener(ActivityListener l) { activityListeners.add(l); }
    public void removeActivityListener(ActivityListener l) { activityListeners.remove(l); }

    private void changed() {
        save();
        for (Listener l : new ArrayList<>(listeners)) l.onChanged();
    }

    // =====================================================================
    // Firebase 연결
    // =====================================================================

    private void initFirebase(Context ctx) {
        if (FirebaseApp.getApps(ctx).isEmpty()) {
            status = "혼자 모드 (Firebase 미연결)";
            return;
        }
        try {
            db = FirebaseDatabase.getInstance();
            try {
                db.setPersistenceEnabled(true); // 오프라인에서 고친 것도 저장
            } catch (Exception ignored) {
                // 이미 DB를 사용한 뒤에는 설정 불가
            }
            auth = FirebaseAuth.getInstance();
        } catch (Exception e) {
            db = null;
            status = "Firebase 설정 오류: 실시간 DB를 만든 뒤 google-services.json 을 다시 받으세요";
            return;
        }
        status = "Firebase 연결 중…";
        if (auth.getCurrentUser() != null) {
            onSignedIn(auth.getCurrentUser().getUid());
        } else {
            auth.signInAnonymously().addOnCompleteListener(task -> {
                if (task.isSuccessful() && auth.getCurrentUser() != null) {
                    onSignedIn(auth.getCurrentUser().getUid());
                } else {
                    status = "Firebase 로그인 실패: Authentication 에서 '익명' 로그인을 켜 주세요";
                    changed();
                }
            });
        }
    }

    private void onSignedIn(String signedInUid) {
        uid = signedInUid;
        String saved = prefs.getString("cloudTripId", null);
        if (saved != null) {
            subscribe(saved);
        } else {
            // 처음 연결: 지금 폰에 있는 일정을 그대로 올려서 내 첫 팀 여행으로
            createCloudTrip(true, null);
        }
    }

    /** 새 여행(팀)을 Firebase에 만들고 그 여행을 구독 */
    private void createCloudTrip(final boolean uploadCurrent, @Nullable final Result cb) {
        final String id = db.getReference("trips").push().getKey();
        final String code = randomCode();

        Map<String, Object> mem = new HashMap<>();
        mem.put(uid, userName);
        Map<String, Object> trip = new HashMap<>();
        trip.put("title", title);
        trip.put("inviteCode", code);
        trip.put("ownerUid", uid);
        trip.put("dayCount", uploadCurrent ? dayCount : 2);
        trip.put("ended", uploadCurrent && ended);
        trip.put("createdAt", ServerValue.TIMESTAMP);
        trip.put("members", mem);

        Map<String, Object> first = new HashMap<>();
        first.put("trips/" + id, trip);
        first.put("invites/" + code, id);

        status = "새 여행을 만드는 중…";
        db.getReference().updateChildren(first).addOnCompleteListener(t -> {
            if (!t.isSuccessful()) {
                status = "여행을 만들지 못했어요: " + msg(t.getException()) + " (DB 규칙을 확인하세요)";
                changed();
                if (cb != null) cb.done(status);
                return;
            }
            // 2) 일정 올리기 (팀원이 된 다음이라 규칙 통과)
            if (uploadCurrent && !days.isEmpty()) {
                Map<String, Object> all = new HashMap<>();
                for (Map.Entry<String, List<PlanItem>> e : days.entrySet()) {
                    for (PlanItem p : e.getValue()) {
                        String itemId = db.getReference().push().getKey();
                        if (p.authorUid == null) {
                            p.authorUid = uid;
                            p.authorName = userName;
                        }
                        all.put(e.getKey() + "/" + itemId, p.toMap());
                    }
                }
                db.getReference("tripDays").child(id).updateChildren(all);
            }
            subscribe(id);
            if (cb != null) cb.done(null);
        });
    }

    /** 이 여행의 변경 사항을 실시간으로 받기 */
    private void subscribe(final String id) {
        unsubscribe();
        tripId = id;
        prefs.edit().putString("cloudTripId", id).apply();
        tripRef = db.getReference("trips").child(id);
        daysRef = db.getReference("tripDays").child(id);

        tripListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot s) {
                if (!s.exists()) return;
                Object t = s.child("title").getValue();
                if (t instanceof String) title = (String) t;
                Object dc = s.child("dayCount").getValue();
                if (dc instanceof Number) dayCount = Math.max(1, ((Number) dc).intValue());
                ended = Boolean.TRUE.equals(s.child("ended").getValue());
                Object code = s.child("inviteCode").getValue();
                inviteCode = code instanceof String ? (String) code : null;
                Object owner = s.child("ownerUid").getValue();
                ownerUid = owner instanceof String ? (String) owner : null;
                members.clear();
                for (DataSnapshot m : s.child("members").getChildren()) {
                    Object name = m.getValue();
                    members.put(m.getKey(), name instanceof String ? (String) name : "여행자");
                }
                status = "실시간 동기화 중";
                changed();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) {
                // 저장된 여행에 더 이상 접근할 수 없음 (규칙 변경, 앱 재설치로 계정이 바뀜 등)
                unsubscribe();
                prefs.edit().remove("cloudTripId").apply();
                if (recreatedOnce) {
                    status = "여행을 불러오지 못했어요: " + e.getMessage()
                            + " (Realtime Database 규칙을 확인하세요)";
                    changed();
                    return;
                }
                recreatedOnce = true;
                status = "이전 여행을 불러오지 못해 새 여행을 만들었어요";
                createCloudTrip(true, null);
            }
        };
        tripRef.addValueEventListener(tripListener);

        daysListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot s) {
                Map<String, List<PlanItem>> fresh = new LinkedHashMap<>();
                for (DataSnapshot day : s.getChildren()) {
                    List<PlanItem> list = new ArrayList<>();
                    for (DataSnapshot it : day.getChildren()) {
                        Object v = it.getValue();
                        if (v instanceof Map) list.add(PlanItem.fromMap(it.getKey(), (Map<?, ?>) v));
                    }
                    fresh.put(day.getKey(), list);
                }
                days = fresh;
                changed();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) { }
        };
        daysRef.addValueEventListener(daysListener);

        // 친구 활동 (지금 이후 것만)
        activityQuery = db.getReference("activity").child(id)
                .orderByChild("at").startAt((double) System.currentTimeMillis());
        activityChildListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot s, @Nullable String prev) {
                Object who = s.child("uid").getValue();
                if (who == null || who.equals(uid)) return; // 내가 한 건 알리지 않음
                Object name = s.child("name").getValue();
                Object message = s.child("message").getValue();
                for (ActivityListener l : new ArrayList<>(activityListeners)) {
                    l.onActivity(name instanceof String ? (String) name : "친구",
                            message instanceof String ? (String) message : "일정을 바꿨어요");
                }
            }

            @Override public void onChildChanged(@NonNull DataSnapshot s, @Nullable String p) { }
            @Override public void onChildRemoved(@NonNull DataSnapshot s) { }
            @Override public void onChildMoved(@NonNull DataSnapshot s, @Nullable String p) { }
            @Override public void onCancelled(@NonNull DatabaseError e) { }
        };
        activityQuery.addChildEventListener(activityChildListener);

        status = "실시간 동기화 중";
        changed();
    }

    private void unsubscribe() {
        if (tripRef != null && tripListener != null) tripRef.removeEventListener(tripListener);
        if (daysRef != null && daysListener != null) daysRef.removeEventListener(daysListener);
        if (activityQuery != null && activityChildListener != null) {
            activityQuery.removeEventListener(activityChildListener);
        }
        tripListener = null;
        daysListener = null;
        activityChildListener = null;
        tripId = null;
        members.clear();
    }

    private void logActivity(String message) {
        if (!isCloud()) return;
        Map<String, Object> a = new HashMap<>();
        a.put("uid", uid);
        a.put("name", userName);
        a.put("message", message);
        a.put("at", ServerValue.TIMESTAMP);
        db.getReference("activity").child(tripId).push().setValue(a);
    }

    private static String msg(@Nullable Exception e) {
        return e != null && e.getMessage() != null ? e.getMessage() : "알 수 없는 오류";
    }

    private static String randomCode() {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 헷갈리는 0/O, 1/I 제외
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) sb.append(chars.charAt(r.nextInt(chars.length())));
        return sb.toString();
    }

    // =====================================================================
    // 폰에 저장/불러오기 (혼자 모드 + 팀 모드의 마지막 상태 보관)
    // =====================================================================

    private void save() {
        try {
            JSONObject root = new JSONObject();
            root.put("title", title);
            root.put("userName", userName);
            root.put("dayCount", dayCount);
            root.put("ended", ended);
            JSONObject d = new JSONObject();
            for (Map.Entry<String, List<PlanItem>> e : days.entrySet()) {
                JSONArray arr = new JSONArray();
                for (PlanItem p : e.getValue()) arr.put(p.toJson());
                d.put(e.getKey(), arr);
            }
            root.put("days", d);
            prefs.edit().putString("data", root.toString()).apply();
        } catch (JSONException ignored) {
            // 저장 실패 시 이번 변경만 저장되지 않음
        }
    }

    private void load(String json) {
        try {
            JSONObject root = new JSONObject(json);
            title = root.optString("title", title);
            userName = root.optString("userName", userName);
            dayCount = root.optInt("dayCount", 2);
            ended = root.optBoolean("ended", false);
            JSONObject d = root.optJSONObject("days");
            if (d != null) {
                JSONArray names = d.names();
                for (int i = 0; names != null && i < names.length(); i++) {
                    String key = names.getString(i);
                    JSONArray arr = d.getJSONArray(key);
                    List<PlanItem> list = new ArrayList<>();
                    for (int j = 0; j < arr.length(); j++) list.add(PlanItem.fromJson(arr.getJSONObject(j)));
                    days.put(key, list);
                }
            }
        } catch (JSONException e) {
            days.clear();
            seedSample();
        }
    }

    /** 처음 실행할 때 시안의 예시 일정 */
    private void seedSample() {
        PlanItem a = PlanItem.place("몬자야키", 4.0, "Open 10:00 ~ 22:00", 34.6690, 135.5030);
        a.time = "12:00";
        a.id = UUID.randomUUID().toString();
        PlanItem b = PlanItem.place("오사카성", 4.0, "Open 09:00 ~ 17:00", 34.6873, 135.5262);
        b.time = "14:30";
        b.id = UUID.randomUUID().toString();
        List<PlanItem> d1 = new ArrayList<>();
        d1.add(a);
        d1.add(b);
        days.put("day1", d1);
    }
}
