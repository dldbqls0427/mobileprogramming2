package com.example.japantrip;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 화면 2: 다이어리와 계획
 * 날짜별로 장소·메모를 추가/수정/삭제하고, 폰에 저장됩니다.
 */
public class PlanFragment extends Fragment implements TripStorage.Listener {

    private TripStorage storage;
    private final Set<String> editingDays = new HashSet<>();
    private GoogleMap previewMap;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_plan, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        storage = TripStorage.get(requireContext());

        // 솔로/팀 칩, 친구 추가 → 팀 창 (초대 코드)
        v.findViewById(R.id.chip_solo).setOnClickListener(b -> TeamDialog.show(requireActivity()));
        v.findViewById(R.id.chip_friend).setOnClickListener(b -> TeamDialog.show(requireActivity()));

        v.findViewById(R.id.map_preview).setOnClickListener(b ->
                ((MainActivity) requireActivity()).showPlaceOnMap(firstPlace()));

        v.findViewById(R.id.btn_add_day).setOnClickListener(b -> storage.addDay());
        v.findViewById(R.id.btn_add_day).setOnLongClickListener(b -> {
            confirmRemoveLastDay();
            return true;
        });

        // 상단 지도 미리보기: 날짜별 색깔 핀 + 이동 순서 선 (가벼운 정지 지도)
        boolean hasMap = MapHelper.attach(this, R.id.map_preview, true, m -> {
            previewMap = m;
            previewMap.setOnMapClickListener(p ->
                    ((MainActivity) requireActivity()).showPlaceOnMap(firstPlace()));
            previewMap.setOnMarkerClickListener(marker -> {
                Place p = TripRepository.find(marker.getTitle());
                ((MainActivity) requireActivity()).showPlaceOnMap(p != null ? p : firstPlace());
                return true;
            });
            drawPreview();
        });
        v.findViewById(R.id.tv_plan_map_placeholder).setVisibility(hasMap ? View.GONE : View.VISIBLE);

        storage.addListener(this);
        render();
    }

    @Override
    public void onDestroyView() {
        storage.removeListener(this);
        previewMap = null;
        super.onDestroyView();
    }

    /** 미리보기 지도에 일정 핀과 동선 그리기 */
    private void drawPreview() {
        if (previewMap == null || getView() == null) return;
        previewMap.clear();
        List<LatLng> all = new ArrayList<>();
        int pad = PlaceViews.dp(requireContext(), 3);
        for (int n = 1; n <= storage.dayCount(); n++) {
            PolylineOptions line = new PolylineOptions()
                    .color(MapHelper.dayColor(n))
                    .width(pad * 2);
            int points = 0;
            for (PlanItem it : storage.items(TripStorage.dayKey(n))) {
                if (it.isMemo() || !it.hasLocation()) continue;
                LatLng pos = new LatLng(it.lat, it.lng);
                previewMap.addMarker(new MarkerOptions().position(pos).title(it.name).icon(MapHelper.dayPin(n)));
                line.add(pos);
                all.add(pos);
                points++;
            }
            if (points >= 2) previewMap.addPolyline(line);
        }
        MapHelper.fit(previewMap, all, PlaceViews.dp(requireContext(), 40));
    }

    @Override
    public void onChanged() {
        render();
        drawPreview();
    }

    private void render() {
        View v = getView();
        if (v == null) return;

        int members = storage.memberCount();
        ((TextView) v.findViewById(R.id.tv_sync)).setText(storage.title() + " · " + storage.status()
                + (members > 1 ? "\n함께하는 사람: " + storage.memberNames() : ""));
        TextView solo = v.findViewById(R.id.chip_solo);
        solo.setText(members > 1 ? "팀 " + members + "명" : "솔로");
        solo.setSelected(true);

        LinearLayout container = v.findViewById(R.id.days_container);
        container.removeAllViews();
        LayoutInflater inf = LayoutInflater.from(requireContext());

        for (int n = 1; n <= storage.dayCount(); n++) {
            final String dayKey = TripStorage.dayKey(n);
            List<PlanItem> items = storage.items(dayKey);

            View dayView = inf.inflate(R.layout.item_day, container, false);
            ((TextView) dayView.findViewById(R.id.tv_day)).setText(dayKey);

            // 일정이 있는 날은 연필 아이콘을 눌러야 추가 버튼이 보임 (시안의 day1/day2 모양)
            boolean showAdd = items.isEmpty() || editingDays.contains(dayKey);
            dayView.findViewById(R.id.add_row).setVisibility(showAdd ? View.VISIBLE : View.GONE);
            dayView.findViewById(R.id.btn_edit_day).setVisibility(items.isEmpty() ? View.INVISIBLE : View.VISIBLE);
            dayView.findViewById(R.id.btn_edit_day).setOnClickListener(b -> {
                if (!editingDays.remove(dayKey)) editingDays.add(dayKey);
                render();
            });
            dayView.findViewById(R.id.btn_add_place).setOnClickListener(b ->
                    ItemEditDialog.show(requireContext(), dayKey, null, PlanItem.TYPE_PLACE));
            dayView.findViewById(R.id.btn_add_memo).setOnClickListener(b ->
                    ItemEditDialog.show(requireContext(), dayKey, null, PlanItem.TYPE_MEMO));

            LinearLayout box = dayView.findViewById(R.id.items_container);
            for (PlanItem item : items) {
                box.addView(item.isMemo() ? memoCard(inf, box, item, dayKey) : placeCard(inf, box, item, dayKey));
            }
            container.addView(dayView);
        }
    }

    private View placeCard(LayoutInflater inf, ViewGroup parent, final PlanItem item, final String dayKey) {
        View card = inf.inflate(R.layout.item_place, parent, false);
        PlaceViews.bind(card, item.name, item.rating, item.hours);
        ((TextView) card.findViewById(R.id.tv_time)).setText(item.time != null ? item.time : "");
        TextView note = card.findViewById(R.id.tv_note);
        if (item.note != null && !item.note.isEmpty()) {
            note.setVisibility(View.VISIBLE);
            note.setText("✎ " + item.note);
        }
        String author = authorLine(item);
        ((TextView) card.findViewById(R.id.tv_author)).setText(
                (author.isEmpty() ? "" : author + " · ") + "길게 누르면 장소 보기");
        card.setOnClickListener(b -> ItemEditDialog.show(requireContext(), dayKey, item, null));
        card.setOnLongClickListener(b -> {
            ((MainActivity) requireActivity()).showPlaceOnMap(Place.from(item));
            return true;
        });
        return card;
    }

    private View memoCard(LayoutInflater inf, ViewGroup parent, final PlanItem item, final String dayKey) {
        View card = inf.inflate(R.layout.item_memo, parent, false);
        String prefix = item.time != null ? item.time + "  " : "";
        ((TextView) card.findViewById(R.id.tv_memo)).setText(prefix + item.name);
        String author = authorLine(item);
        TextView tvAuthor = card.findViewById(R.id.tv_author);
        if (author.isEmpty()) tvAuthor.setVisibility(View.GONE);
        else tvAuthor.setText(author);
        card.setOnClickListener(b -> ItemEditDialog.show(requireContext(), dayKey, item, null));
        return card;
    }

    /** "민지님이 작성" / "내가 작성" (혼자 모드면 빈칸) */
    private String authorLine(PlanItem item) {
        if (!storage.isCloud() || item.authorName == null) return "";
        return storage.isMine(item) ? "내가 작성" : item.authorName + "님이 작성";
    }

    private void confirmRemoveLastDay() {
        final int last = storage.dayCount();
        if (last <= 1) return;
        new AlertDialog.Builder(requireContext())
                .setMessage("day" + last + "를 삭제할까요? 그날 일정도 함께 지워져요.")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제", (d, w) -> storage.removeLastDay())
                .show();
    }

    @Nullable
    private Place firstPlace() {
        for (PlanItem p : storage.items("day1")) if (!p.isMemo()) return Place.from(p);
        return null;
    }
}
