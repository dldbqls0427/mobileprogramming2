# 일본여행어쩌고 — 3단계 (Firebase: 친구와 함께)

## 3단계에서 추가된 것
- **초대 코드로 친구를 팀으로 묶기** (My다이어리 → 친구 추가 / 마이페이지 → 친구 초대 · 팀)
- **여러 명이 같은 일정을 동시에 편집, 실시간 동기화** (Firebase Realtime Database)
- **친구가 일정을 추가·수정·삭제하면 알림** (앱이 켜져 있을 때)
- 카드마다 "민지님이 작성" 표시, 타임라인에 함께한 사람 표시

## Firebase 연결
1. Firebase 콘솔에서 프로젝트 만들기
2. Realtime Database 만들기(싱가포르) → 규칙 탭에 `firebase/database.rules.json` 붙여넣고 게시
3. Authentication → 익명 로그인 사용 설정
4. Android 앱 등록(`com.example.japantrip`) → **google-services.json 을 `app/` 폴더에** 넣기
5. Sync → ▶ 실행 → 마이페이지에 "실시간 동기화 중"이 보이면 성공

`google-services.json` 이 없으면 2단계처럼 **혼자 모드**로 동작해요.

---

# (이전) 2단계 (Google 지도)

1단계 기본 기능 + **Google Maps SDK for Android** 연동.
지도 키가 없으면 지도 자리가 회색 칸으로 나오고, 나머지 기능은 그대로 동작해요.

## 지도 API 키 넣기
1. https://console.cloud.google.com → 새 프로젝트
2. API 및 서비스 → 라이브러리 → **Maps SDK for Android** 사용 설정
3. 사용자 인증 정보 → API 키 만들기 → 복사
4. `local.properties` 맨 아래에 추가 (Git에 안 올라가요)
   ```
   MAPS_API_KEY=AIza...
   ```
5. Android Studio 위쪽 코끼리 아이콘(Sync) → ▶ 실행
6. 에뮬레이터는 **Google Play가 들어간 이미지**여야 지도가 떠요

## 지도가 나오는 곳
| 화면 | 지도 기능 |
|---|---|
| 지도 탭 | 내 일정 장소를 날짜별 색깔 핀으로 표시(day1 빨강, day2 파랑, day3 초록…), 보고 있는 장소는 보라 핀, 핀 누르면 아래 정보가 그 장소로 바뀜 |
| My다이어리 | 위쪽 미리보기 지도에 날짜별 핀 + 이동 순서 선, 누르면 지도 탭으로 |
| 여행교통 | 출발(초록)·도착(빨강) 핀과 점선 연결 |


## 실행
1. Android Studio → **Open** → 이 폴더(`JapanTrip`)
2. "Gradle JVM" 창이 뜨면 **Use JVM 21**
3. 위쪽 ▶ 실행

## 들어간 기능
| 탭 | 기능 |
|---|---|
| 홈 | 배너 자동 넘김, #맛집/#관광 평점순 TOP3 + 추천 목록, 장소 누르면 상세 |
| 여행교통 | 출발·도착 입력, 대중교통/버스/자전거/도보 예상 시간·요금 (앱에서 계산) |
| 지도 | 장소 상세(별점·영업시간), **내 일정에 추가**(날짜 선택), 길찾기 |
| My다이어리 | 날짜별 장소·메모 추가/수정/삭제, 시간순 정렬, 날짜 추가(길게 누르면 마지막 날 삭제) |
| 마이페이지 | 내 이름·여행 이름 바꾸기, 타임라인, 새 여행 시작 |
| 타임라인 | 전체 일정을 날짜·시간 순서로 정리 |

일정은 **폰에 저장**돼서 앱을 껐다 켜도 남아 있어요. (`TripStorage.java`)

## 파일 안내 (`app/src/main/java/com/example/japantrip`)
- `TripStorage` 일정 저장/불러오기 — 혼자 모드(폰 저장) / 팀 모드(Firebase) 자동 전환
- `TeamDialog` 초대 코드·팀원·참여, `Notifier` 친구 소식 알림
- `TripRepository` 앱에 들어 있는 장소 목록
- `PlanItem` 일정 한 칸, `Place` 장소 정보
- `*Fragment` 각 화면, `ItemEditDialog` 장소·메모 입력 창
- `RouteEstimator` 이동 시간·요금 계산
- `MapHelper` 지도 만들기, 날짜별 핀 색, 화면 맞추기

## 다음 단계
~~2단계 Google 지도~~ → ~~3단계 Firebase~~ → 4단계 Spring Boot 서버
